#!/bin/bash

echo "Running script"

./build/chat_client src/claire.properties
